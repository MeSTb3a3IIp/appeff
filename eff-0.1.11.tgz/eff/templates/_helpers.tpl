{{/* helpers for eff chart */}}
{{- define "eff.name" -}}
{{- default .Chart.Name .Values.nameOverride -}}
{{- end -}}

{{- define "eff.fullname" -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if .Release.Name -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "eff.labels" -}}
app.kubernetes.io/name: {{ include "eff.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}
